export const PORT = 5555;

export const mongoDBURL =
    'mongodb+srv://root:root@test.2hkxi1d.mongodb.net/test?retryWrites=true&w=majority'